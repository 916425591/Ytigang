<template>
  <div id="login">
        hello login
  </div>
</template>

<script>
  export default {
    name: 'login',
    components:{
    
    },
    data:function(){
      return{
      
      }
    },
    methods: {
      
    }
  }
</script>

<style scoped>

</style>